library(RODBC)
library(readr)
library(dplyr)
library(ggplot2)
library(scales)
library(DT)
library(knitr)
library(tidyr)
library(SIAtoolbox)

setwd("~/Network-Shares/Datalab-MA/MAA2016-15 Supporting the Social Investment Unit/Kylie/2015 ERP/Markdown/TA_template")
getwd()

###Set DB name and create connection string
connstr <- set_conn_string(db = "IDI_Sandpit")

###Load sql script to object
data_query <- file("data_query.sql")

###Read in SQL table
tmp <- as_tibble(read_sql_table(query_object = data_query, connection_string = connstr))

###Write to RDS file
write_rds(tmp, "final_Fijian_2015.rds")

rmarkdown::render("TA_template.Rmd")


