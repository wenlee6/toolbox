select *,
  'New Zealand' as pop_ind 
from
  [IDI_Sandpit].[DL-MAA2016-15].[DF_2015_alldata] 
  
union all 

select *,
  'Fijian' as pop_ind 
from 
  [IDI_Sandpit].[DL-MAA2016-15].[DF_2015_alldata]
where Fijian = 'Yes'
