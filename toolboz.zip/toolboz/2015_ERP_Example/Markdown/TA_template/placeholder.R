
### Mental health service use

### ACC injury claims

### Self-harm related service use

Self-harm occurances are recorded when a patient uses either a health or ACC survice

### Substance use service use

### Total health spending

This include costs that can be attributed to individuals from ...

## Education related measures

### Highest qualification

These include...

### Early childhood attendance

### Te reo speakers

### Tertiary education enrolments

This includes university and industry training

## Crime and safety measures

### CYF contacts

Proportion with a CYF contact record

### Family Violence

Proportion with a recorded family violence record

### Victims of crime

### Offenders

### Total justice spending

This includes costs that can be attributed to individuals from courts and sentancing and remand data

## Other government service use measures

### Main benefit receipt

### Total government spending 




Social investment requires a holistic view of people. This means that analysis needs to be preformed using data that represents aspects of people's lives. This lets us understand more baout the real life experiences of the population we study.

Statistics NZ's Integrated Data Infrastructure (IDI) is the most complete integrated data source in New Zealand. It includes data from areas including health, education, welfare, justice, and employment. This report is a demonstration of the information that can be drawn from the IDI about people and their life experiences captured through integrated data. 

## Using data responsibly



These are simple descriptive statitsics and do not imply causality. Just because two data insights follow a similar trend doesn't mean that they are directly related to on another; other factors may be at play behind the data and we need to be aware of them before making assumptions.