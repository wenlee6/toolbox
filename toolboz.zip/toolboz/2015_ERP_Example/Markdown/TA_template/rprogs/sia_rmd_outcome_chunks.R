### SIA rmd outcome chunks

## Age
age_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("as_at_age") %>%
    filter(between(as_at_age, 1,100 ))
  
  plt <- df_rr3 %>% ggplot_siu_line("as_at_age", "prop", "pop_ind", "Age", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("as_at_age")
  
  return(list(plot = plt, table = tb))
  
} 

## Income
income_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3_adults_working("income") 
  
  plt <- df_rr3 %>% ggplot_siu_bar("income", "prop", "pop_ind", "Income", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("income")
  
  return(list(plot = plt, table = tb))
  
} 

## Chronic Conditions
chronic_cond_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("MOH_Chronic_flg_char") %>%
    filter(MOH_Chronic_flg_char == "Yes")

  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("MOH_Chronic_flg_char", "prop", "pop_ind", "Chronic Condition", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("MOH_Chronic_flg_char")
  
  return(list(plot = plt, table = tb))
  
} 

## Number of address changes in 12 months
add_change_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3_adults("Nbr_add_changes") %>%
    filter(Nbr_add_changes <= 4)
    
    
    plt <- df_rr3 %>% ggplot_siu_bar("Nbr_add_changes", "prop", "pop_ind", "Number of address changes", "Proportion")
    
    tb <- df_rr3 %>% siu_rmd_table("Nbr_add_changes")
    
    return(list(plot = plt, table = tb))
    
} 

## Households with children under 18
hh_under18_chunk <- function(){
    
    df_rr3 <- pop_counts_rr3("Child_Hh_char") %>%
      filter(Child_Hh_char == 'Yes')
    
    plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("Child_Hh_char", "prop", "pop_ind", "Households with children under 18", "Proportion")
    
    tb <- df_rr3 %>% siu_rmd_table( "Child_Hh_char")
    
    return(list(plot = plt, table = tb))
    
  }


## Contact record

cnp_event_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3_0_12("contact_record_char") %>%
    filter(contact_record_char == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("contact_record_char", "prop", "pop_ind", "CYF contact record", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("contact_record_char")
  
  return(list(plot = plt, table = tb))
  
}

## Family Violence

famv_event_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3_0_12("police_fv_char") %>%
    filter(police_fv_char == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("police_fv_char", "prop", "pop_ind", "Family violence record", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("police_fv_char")
  
  return(list(plot = plt, table = tb))
  
}

## Victims of crime

victim_event_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("Victim_flg_char") %>%
    filter(Victim_flg_char == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("Victim_flg_char", "prop", "pop_ind", "Victims of crime", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("Victim_flg_char")
  
  return(list(plot = plt, table = tb))
  
}

## Offenders

offender_event_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3_adults("Offender_flg_char") %>%
    filter(Offender_flg_char == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("Offender_flg_char", "prop", "pop_ind", "Offenders", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("Offender_flg_char")
  
  return(list(plot = plt, table = tb))
  
}

## Total justice spending

## Other government service use measures

## Main benefit receipt

msd_event_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3_adults("MSD_flag_char") %>%
    filter(MSD_flag_char == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("MSD_flag_char", "prop", "pop_ind", "Benefit receipt", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("MSD_flag_char")
  
  return(list(plot = plt, table = tb))
  
}

## Total government spending 



## CYF abuse event
# cyf_abuse_chunk <- function(){
#   
#   df_rr3 <- pop_counts_rr3("cyf_abuse") %>%
#     filter(cyf_abuse == "Yes")
#   
#   plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("cyf_abuse", "prop", "pop_ind", "CYF Abuse", "Proportion")
#   
#   tb <- df_rr3 %>% siu_rmd_table("cyf_abuse")
#   
#   return(list(plot = plt, table = tb))
#   
# } 

# ## Ethnicity
# ethnicity_chunk <- function(){
#   
#   df_rr3 <- pop_counts_rr3("ethnicity")
#   
#   plt <- df_rr3 %>% ggplot_siu_bar("ethnicity", "prop", "pop_ind", "Ethnicity", "Proportion")
#   
#   tb <- df_rr3 %>% siu_rmd_table( "ethnicity")
#   
#   return(list(plot = plt, table = tb))
#   
# }

## Maori ethnicity (all, not prioritised)
ethnicity_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("Maori_char") %>%
    filter(Maori_char != 'Missing')
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("Maori_char", "prop", "pop_ind", "Maori ethnicity", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table( "Maori_char")
  
  return(list(plot = plt, table = tb))
  
}

## Gender
gender_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("sex_char") %>%
  filter(sex_char != 'Missing')
  
  plt <- df_rr3 %>% ggplot_siu_bar("sex_char", "prop", "pop_ind", "Gender", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("sex_char")
  
  return(list(plot = plt, table = tb))
  
}

## Hospital Admissions
hosp_admit_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("hosp_ct_2yrs_band")
            filter(cyf_abuse == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar("hosp_ct_2yrs_band", "prop", "pop_ind", "Admissions to Hospital", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("hosp_ct_2yrs_band")
  
  return(list(plot = plt, table = tb))
  
} 

## NZ Deprivation Index
dep_index_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("dep_index") %>%
    na.omit()
  
  plt <- df_rr3 %>% ggplot_siu_bar("dep_index", "prop", "pop_ind", "NZ Deprivation Decile", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("dep_index")
  
  return(list(plot = plt, table = tb))
  
} 

## PHO enrolment (not enrolled)
pho_enrol_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("no_phoenrol_ind_2yrs") %>%
    filter(no_phoenrol_ind_2yrs == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("no_phoenrol_ind_2yrs", "prop", "pop_ind", "Child not enrolled", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("no_phoenrol_ind_2yrs")
  
  return(list(plot = plt, table = tb))
  
}

## Region
region_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("region_collapse") %>%
    filter(!(region_collapse %in% c("Area Outside", "Area Outside Region")))
  
  plt <- df_rr3 %>% ggplot_siu_column("region_collapse", "prop", "pop_ind", "Region", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("region_collapse")
  
  return(list(plot = plt, table = tb))
  
} 

## Social Housing Tenancy
soc_house_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("sh_indicator_2yrs") %>%
    filter(sh_indicator_2yrs == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("sh_indicator_2yrs", "prop", "pop_ind", "Social Housing Tenant", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("sh_indicator_2yrs")
  
  return(list(plot = plt, table = tb))
  
}  

## Youth Justice Event
yju_event_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("yju_event") %>%
    filter(yju_event == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("yju_event", "prop", "pop_ind", "Youth Justice Event", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("yju_event")
  
  return(list(plot = plt, table = tb))
  
} 


## B4SC outcome

b4sc_event_chunk  <- function(){
  
  df_rr3 <- pop_counts_rr3("b4sc_outcome") %>%
    filter(b4sc_outcome != "Missing") %>%
    filter(b4sc_outcome != "Referral Declined")
  
  plt <- df_rr3 %>% ggplot_siu_bar("b4sc_outcome", "prop", "pop_ind", "B4School Check outcome", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("b4sc_outcome")
  
  return(list(plot = plt, table = tb))
  
} 

## Disability needs

disability_event_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("disability_flag_char") %>%
    filter(disability_flag_char == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("disability_flag_char", "prop", "pop_ind", "Disability needs", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("disability_flag_char")
  
  return(list(plot = plt, table = tb))
  
} 


## Mothers age at first birth


birth_age_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("age_at_first_birth") %>%
    filter(between(age_at_first_birth, 1,55 ))
  
  plt <- df_rr3 %>% ggplot_siu_line("age_at_first_birth", "prop", "pop_ind", "Mothers age", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("age_at_first_birth")
  
  return(list(plot = plt, table = tb))
  
} 


# Mental health

mental_health_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("mh_ind_char") %>%
    filter(mh_ind_char == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("mh_ind_char", "prop", "pop_ind", "Mental health service use", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("mh_ind_char")
  
  return(list(plot = plt, table = tb))
  
} 

## Substance use

substance_use_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("sub_abe_ind_char") %>%
    filter(sub_abe_ind_char == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("sub_abe_ind_char", "prop", "pop_ind", "Substance use service use", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("sub_abe_ind_char")
  
  return(list(plot = plt, table = tb))
  
} 

## Self harm

self_harm_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("SLF_HRM_flg_char") %>%
    filter(SLF_HRM_flg_char == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("SLF_HRM_flg_char", "prop", "pop_ind", "Self harm service use", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("SLF_HRM_flg_char")
  
  return(list(plot = plt, table = tb))
  
} 

## Teen parent

teen_parent_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3_10_plus_females("teen_parent_char") %>%
    filter(teen_parent_char == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("teen_parent_char", "prop", "pop_ind", "Teen parents", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("teen_parent_char")
  
  return(list(plot = plt, table = tb))
  
} 


## Injuries

acc_injury_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("ACC_INJ_FLG_char") %>%
    filter(ACC_INJ_FLG_char == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("ACC_INJ_FLG_char", "prop", "pop_ind", "Injuries", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("ACC_INJ_FLG_char")
  
  return(list(plot = plt, table = tb))
  
} 

## Education nqflevel

education_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3_adults("nqflevel_char") 
  
  
  plt <- df_rr3 %>% ggplot_siu_bar("nqflevel_char", "prop", "pop_ind", "NQF level", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("nqflevel_char")
  
  return(list(plot = plt, table = tb))
  
} 

## ECE

ece_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3_0_5("ece__flag_char") %>%
    filter(ece__flag_char == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("ece__flag_char", "prop", "pop_ind", "ECE attendance", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("ece__flag_char")
  
  return(list(plot = plt, table = tb))
  
} 


## Te reo speaker

tereo_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3_0_12("tereo_speaker_char") %>%
    filter(tereo_speaker_char == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("tereo_speaker_char", "prop", "pop_ind", "Te Reo speakers", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("tereo_speaker_char")
  
  return(list(plot = plt, table = tb))
  
}

## TEC enrollments

tec_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3_adults("MOE_furtherEd_char") %>%
    filter(MOE_furtherEd_char == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("MOE_furtherEd_char", "prop", "pop_ind", "Tertiary education enrolments", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("MOE_furtherEd_char")
  
  return(list(plot = plt, table = tb))
  
}




