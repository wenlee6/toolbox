###Read in and pre-preocess data

# ###Set DB name and create connection string
# connstr <- set_conn_string(db = "IDI_Sandpit")
# 
# ###Load sql script to object
# data_query <- file("data_query.sql")

# ###Read in SQL table
# tmp <- as_tibble(read_sql_table(query_object = data_query, connection_string = connstr))

###########################################################################

###Renaming and deriving new vars etc.

tmp <- read_rds("final_Fijian_2015.rds")

analysis_dataset <- tmp %>%
  rename(
    ethnicity = prioritised_eth
    # ,region = ant_region_code
    ,gender = snz_sex_code
  ) %>%
  mutate(
    ## Reorder pop_ind
    pop_ind = factor(pop_ind, levels = c('New Zealand', 'Fijian'))
      ,income = cut(tot_admin_income, breaks=c(-Inf,0,30000,60000,100000,Inf)
                  ,labels=c('No income','1 - 30,000', '30,001-60,000', '60,001-100,000', '100,001+'), right=TRUE)
      ,nqflevel_char = as.factor(nqflevel)
    # ,cyf_abuse = ifelse(cyf_abuse_2yrs_flag == 1, "Yes", "No")
    # ,cnp_event = ifelse(cyf_cnpevent_2yrs_flag == 1, "Yes", "No")
    # ,yju_event = ifelse(cyf_yjuevent_2yrs_flag == 1, "Yes", "No")
    #
    # ,no_phoenrol_ind_2yrs = ifelse(pho_enrolled_flag == 0, "Yes", "No")

    #,dep_index = factor(dep_index)
  )
