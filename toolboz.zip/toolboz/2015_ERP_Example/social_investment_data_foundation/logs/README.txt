Readme file for folder: logs

This folder is used to potentially store the output logs that SAS generates. 

Do not delete this folder. Deleting this folder may mean the main script does not run correctly.