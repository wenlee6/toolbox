# Change Log

all notable changes to this project will be documented in this file

## [1.0.0] - Jun 2017

v1

## [1.0.1] - Jun 2017
* Hash object bug fix
* Corrections cost rollup fix


## [1.1.0] - Aug 2017
* Additional variables
* More unit tests added
* Issue #4 regarding hard coding of schemas is fixed


## [1.1.1] - Aug 2017
* SIAL submodule has been updated and pulled down to SIDF


