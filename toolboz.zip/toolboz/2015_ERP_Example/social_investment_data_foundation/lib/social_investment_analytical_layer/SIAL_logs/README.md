## Readme file for folder: SIAL_logs

This folder is used to store the output logs that SAS generates. Since SAS does not have easy to use error handling the logs are written to file and scanned for errors.

Do not delete this folder. Deleting this folder will mean the main script will not run correctly.
