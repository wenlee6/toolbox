## Readme file for folder: SIAL_dependencies

Data in this folder that has been sourced directly from an agency has been given permission by the corresponding agency to share with the SIAL scripts.

Other data in this folder have been sourced from publically available sites.

Treasury vote information can be found at
http://www.treasury.govt.nz/budget/votehistory

These datasets do not contain person information. They are used to derive costs for the SIAL tables where costs do not exist in the IDI tables.

For any questions please contact info@siu.govt.nz.

Last updated: Jan 2017.
