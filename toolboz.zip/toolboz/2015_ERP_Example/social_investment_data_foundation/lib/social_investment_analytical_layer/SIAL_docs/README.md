## Readme file for folder: SIAL_docs

This folder contains the data dictionary for the SIAL and an overview of the datasets timeline.
