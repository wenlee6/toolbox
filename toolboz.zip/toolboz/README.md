# SIAtoolbox
An R package for the SIA.

## License for the SIAtoolbox Content
[![License: CC BY SA 4.0](https://i.creativecommons.org/l/by-sa/4.0/88x31.png)](https://creativecommons.org/licenses/by-sa/4.0/)

Crown copyright ©. This copyright work is licensed under the Creative Commons Attribution 4.0 International licence. In essence, you are free to copy, distribute and adapt the work, as long as you attribute the work to the New Zealand Government and abide by the other licence terms. 

To view a copy of this licence, visit [https://creativecommons.org/licenses/by-sa/4.0/](https://creativecommons.org/licenses/by-sa/4.0/). 

Please note that neither the New Zealand Government emblem nor the New Zealand Government logo may be used in any way which infringes any provision of the [Flags, Emblems, and Names Protection Act 1981](http://www.legislation.govt.nz/act/public/1981/0047/latest/whole.html) or would infringe such provision if the relevant use occurred within New Zealand. Attribution to the New Zealand Government should be in written form and not by reproduction of any emblem or the New Zealand Government logo.

## License for the SIAtoolbox Code Base
GNU GPLv3 License

Crown copyright (c) 2017, Social Investment Agency on behalf of the New Zealand Government.

See ![LICENSE.md](https://github.com/nz-social-investment-agency/SIAtoolbox/blob/master/LICENSE) for more details.

## Install

1. **Download the zip file or clone to your computer**

2. **Arrange for Statistics NZ to move the folder in to your project area**  

3. **Install and/or load devtools in R**  
`install.packages("devtools")`  
`library(devtools)`

4. **Use the `devtools::install()` function to install folder from where you saved it locally**  
`install("path/to/file/SIAtoolbox")`

5. **Load SIAtoolbox library**  
`library(SIAtoolbox)`
