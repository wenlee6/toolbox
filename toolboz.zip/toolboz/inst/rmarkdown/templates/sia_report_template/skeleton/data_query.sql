select 
  top 1000 *, 
  'Population of interest' as pop_ind 
from
  [IDI_Sandpit].[DL-MAA2016-15].[respop_2013_truancy_8to14] 
  
union all 

select 
  top 2000 *, 
  'Comparison population' as pop_ind 
from 
  [IDI_Sandpit].[DL-MAA2016-15].[respop_2013_truancy_8to14]


  
