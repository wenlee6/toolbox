### SIA rmd outcome chunks

## Age
age_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("age")
  
  plt <- df_rr3 %>% ggplot_siu_line("age", "prop", "pop_ind", "Age", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("age")
  
  return(list(plot = plt, table = tb))
  
} 

## Chronic Conditions
chronic_cond_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("chronic_cond_ind") %>%
    filter(chronic_cond_ind == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("chronic_cond_ind", "prop", "pop_ind", "Chronic Condition", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("chronic_cond_ind")
  
  return(list(plot = plt, table = tb))
  
} 

## CNP event

cnp_event_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("cnp_event") %>%
    filter(cnp_event == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("cnp_event", "prop", "pop_ind", "CNP event", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("cnp_event")
  
  return(list(plot = plt, table = tb))
  
}

## CYF abuse event
cyf_abuse_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("cyf_abuse") %>%
    filter(cyf_abuse == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("cyf_abuse", "prop", "pop_ind", "CYF Abuse", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("cyf_abuse")
  
  return(list(plot = plt, table = tb))
  
} 

## Ethnicity
ethnicity_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("ethnicity")
  
  plt <- df_rr3 %>% ggplot_siu_bar("ethnicity", "prop", "pop_ind", "Ethnicity", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table( "ethnicity")
  
  return(list(plot = plt, table = tb))
  
}

## Gender
gender_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("gender")
  
  plt <- df_rr3 %>% ggplot_siu_bar("gender", "prop", "pop_ind", "Gender", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("gender")
  
  return(list(plot = plt, table = tb))
  
}

## Hospital Admissions
hosp_admit_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("hosp_ct_2yrs_band")
  
  plt <- df_rr3 %>% ggplot_siu_bar("hosp_ct_2yrs_band", "prop", "pop_ind", "Admissions to Hospital", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("hosp_ct_2yrs_band")
  
  return(list(plot = plt, table = tb))
  
} 

## NZ Deprivation Index
dep_index_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("dep_index") %>%
    na.omit()
  
  plt <- df_rr3 %>% ggplot_siu_bar("dep_index", "prop", "pop_ind", "NZ Deprivation Decile", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("dep_index")
  
  return(list(plot = plt, table = tb))
  
} 

## PHO enrolment (not enrolled)
pho_enrol_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("no_phoenrol_ind_2yrs") %>%
    filter(no_phoenrol_ind_2yrs == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("no_phoenrol_ind_2yrs", "prop", "pop_ind", "Child not enrolled", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("no_phoenrol_ind_2yrs")
  
  return(list(plot = plt, table = tb))
  
}

## Region
region_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("region_collapse") %>%
    filter(!(region_collapse %in% c("Area Outside", "Area Outside Region")))
  
  plt <- df_rr3 %>% ggplot_siu_column("region_collapse", "prop", "pop_ind", "Region", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("region_collapse")
  
  return(list(plot = plt, table = tb))
  
} 

## Social Housing Tenancy
soc_house_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("sh_indicator_2yrs") %>%
    filter(sh_indicator_2yrs == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("sh_indicator_2yrs", "prop", "pop_ind", "Social Housing Tenant", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("sh_indicator_2yrs")
  
  return(list(plot = plt, table = tb))
  
}  

## Youth Justice Event
yju_event_chunk <- function(){
  
  df_rr3 <- pop_counts_rr3("yju_event") %>%
    filter(yju_event == "Yes")
  
  plt <- df_rr3 %>% ggplot_siu_bar_no_tick_lab("yju_event", "prop", "pop_ind", "Youth Justice Event", "Proportion")
  
  tb <- df_rr3 %>% siu_rmd_table("yju_event")
  
  return(list(plot = plt, table = tb))
  
} 

