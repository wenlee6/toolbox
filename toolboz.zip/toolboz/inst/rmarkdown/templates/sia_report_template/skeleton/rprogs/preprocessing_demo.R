###Read in and pre-preocess data

###Set DB name and create connection string
connstr <- set_conn_string(db = "IDI_Sandpit")

###Load sql script to object
data_query <- file("data_query.sql")

###Read in SQL table
tmp <- as_tibble(read_sql_table(query_object = data_query, connection_string = connstr))

###########################################################################

###Renaming and deriving new vars etc.

analysis_dataset <- tmp %>%
  rename(
    ethnicity = ethnicity_name
    ,region = region_name
    ,gender = sex_name
  ) %>%
  mutate(
    ## Reorder pop_ind
    pop_ind = factor(pop_ind, levels = c('Population of interest', 'Comparison population'))
    ,region = stringr::str_replace(region, " Region", "")
    ,region_collapse = ifelse(as.character(region) %in% c('Tasman', 'Nelson', 'Marlborough',
                                                          'West Coast', 'Southland', 'Otago'),
                              "Rest of South Island", as.character(region))
    # ,cyf_abuse = ifelse(cyf_abuse_2yrs_flag == 1, "Yes", "No")
    # ,cnp_event = ifelse(cyf_cnpevent_2yrs_flag == 1, "Yes", "No")
    # ,yju_event = ifelse(cyf_yjuevent_2yrs_flag == 1, "Yes", "No")
    #
    # ,no_phoenrol_ind_2yrs = ifelse(pho_enrolled_flag == 0, "Yes", "No")

    ,dep_index = factor(dep_index)
  )
