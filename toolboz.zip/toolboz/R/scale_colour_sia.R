#' SIA ggplot colour scale
#'
#' This is a function for adding the SIA colours to a ggplot plot.
#' @keywords plot ggplot colour
#' @export
#' @examples
#' library(ggplot2)
#' library(SIAtoolbox)
#'
#' ggplot(mtcars, aes(mpg, wt, colour = as.factor(cyl))) +
#' geom_point() +
#' ggtitle("Fuel Economy Data (1999 and 2008)") +
#' theme_sia() +
#' scale_colour_sia()
#'
#' ggplot(iris, aes(Petal.Length, Petal.Width, colour = Species)) +
#' geom_point() +
#' ggtitle("Iris Data") +
#' theme_sia() +
#' scale_colour_sia()

scale_colour_sia <- function(..., values) {
  # ggplot2:::manual_scale("colour", values = c("#588D97", "#F47C20", "#414258", "#315259", "#262638"), ...)
  ggplot2:::manual_scale("colour", values = c("#262638", rep("#BDBAC0",10)), ...)
}
