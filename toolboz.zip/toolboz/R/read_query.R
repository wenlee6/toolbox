#' Read query
#'
#' This function is used by the read_sql_table() function
#' to read in and parse SQL queries
#' @param filename Path to file.
#' @keywords read query
#' @export

read_query <- function(filename){

  paste(readLines(filename), collapse="\n")

}
