#' SIA ggplot fill scale
#'
#' This is a function for adding the SIA fill colours to a ggplot plot.
#' @keywords plot ggplot fill
#' @export
#' @examples
#' library(ggplot2)
#' library(SIAtoolbox)
#'
#' ggplot(diamonds, aes(price)) +
#' geom_histogram(aes(fill = cut)) +
#' ggtitle("Diamonds Data") +
#' theme_sia() +
#' scale_fill_sia()

scale_fill_sia <- function(..., values) {
  # ggplot2:::manual_scale("fill", values = c("#588D97", "#F47C20", "#414258", "#315259", "#262638"), ...)
  ggplot2:::manual_scale("fill", values = c("#262638", rep("#BDBAC0",10)), ...)
}
