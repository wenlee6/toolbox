#' Read SQL table
#'
#' This function reads a table from the SQL server. It requires a SQL
#' query object and a connection string to connect via ODBC. Use in
#' combination with the set_conn_string() function.
#' @param query A SQL query object read in with the file() function. Alternatively, a SQL
#' query string (see examples).
#' @param connection_string The connection string created by the set_conn_string() function.
#' @param string TRUE/FALSE. TRUE allows for writing sql query directly in R as a string. FALSE is used for
#' reading in from a .sql file (this is the default).
#' @keywords read table sql
#' @export
#' @examples
#' ### Load libraries
#' library(SIAtoolbox)
#' library(RODBC)
#'
#' ### Set DB name and create connection string
#' connstr <- set_conn_string(db = "IDI_Sandpit")
#'
#' ### Read in SQL table (using .sql file)
#' data_query <- file("path_to_file/example.sql") #Change to actual path of .sql file
#'
#' sql_table <- read_sql_table(query = data_query, connection_string = connstr)
#'
#' ### Read in SQL table (using string)
#' sql_table <- read_sql_table(query = "select top 10 * from [DL-MAA2016-15].[SIAL_MOE_school_events]",
#' connstr, string = TRUE)

read_sql_table <- function(query = data_query, connection_string = connstr, string = FALSE){

  ###Connect to database
  conn <- odbcDriverConnect(connection = connection_string)

  ###Read table and assign to object.
  ###Using string == TRUE allows for the writing of a SQL query string in R.
  ifelse(string == FALSE,
         tmp <- sqlQuery(channel = conn, query = read_query(query)),
         tmp <- sqlQuery(channel = conn, query = query)
  )


  ###Close connections
  odbcClose(conn)

  return(tmp)

}
