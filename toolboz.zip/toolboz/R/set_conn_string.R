#' Set connection string
#'
#' This function helps to set an ODBC connection
#' string for the IDI's SQL server. It takes the
#' database name as an input paramater.
#' @param db Database name. Defaults to "IDI_Sandpit".
#' @keywords connection
#' @export
#' @examples
#' set_conn_string("IDI_Sandpit")
#' set_conn_string("IDI_Clean")

set_conn_string <- function(db = "IDI_Sandpit"){

  ###Create connection string function - courtesy: Christopher Ball (TSY)

  tmp <- "DRIVER=ODBC Driver 11 for SQL Server; "
  tmp <- paste0(tmp, "Trusted_Connection=Yes; ")
  tmp <- paste0(tmp, paste0("DATABASE=", db, " ; "))
  tmp <- paste0(tmp, "SERVER=WPRDSQL36.stats.govt.nz, 49530")

  return(tmp)
}
