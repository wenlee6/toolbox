#' SIA ggplot theme
#'
#' This is a function for adding the SIA theme to a ggplot plot.
#' @param base_size Base font size
#' @param base_family Base font family
#' @keywords plot ggplot theme
#' @export
#' @examples
#' library(ggplot2)
#' library(SIAtoolbox)
#'
#' ggplot(mtcars, aes(mpg, wt, colour = as.factor(cyl))) +
#' geom_point() +
#' ggtitle("Fuel Economy Data (1999 and 2008)") +
#' theme_sia() +
#' scale_colour_sia()
#'
#' ggplot(iris, aes(Petal.Length, Petal.Width, colour = Species)) +
#' geom_point() +
#' ggtitle("Iris Data") +
#' theme_sia() +
#' scale_colour_sia()
#'
#' ggplot(diamonds, aes(price)) +
#' geom_histogram(aes(fill = cut)) +
#' ggtitle("Diamonds Data") +
#' theme_sia() +
#' scale_fill_sia()

theme_sia <- function(base_size = 12, base_family = "")
{
  half_line <- base_size/2
  theme_minimal(base_size = base_size, base_family = base_family) %+replace%
    theme(
      axis.text = element_text(colour = "#315259", family = 'Century Gothic', size = rel(0.8)),
      axis.title = element_text(colour = "black", family = 'Century Gothic'),
      axis.ticks = element_line(colour = "black"),
      legend.key = element_rect(colour = NA),
      legend.title = element_blank(),
      legend.position = "bottom",
      plot.title = element_text(color = "#588D97", family = 'Century Gothic', size = 15,
                                margin = margin(b = half_line * 1.2)),
      plot.margin = margin(half_line, half_line, half_line, half_line),
      panel.grid = element_blank()
    )
}
