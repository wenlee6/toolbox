#' Random round to base n
#'
#' Developed by Chris Hansen (Statistics NZ)
#' Date: 30/05/16
#'
#' This function takes an object and randomly rounds integer values
#' to a base of the user's choosing
#' @param x The object to pass to the function.
#' @param n The base to randomly round to. Defaults to 3.
#' @param seed A numeric input for the seed. Optional.
#' @keywords random round
#' @export
#' @examples
#' library(SIAtoolbox)
#'
#' dta <- data.frame(x = 1:10, y = 31:40)
#' rrn(dta, 3, 12345)
#'

random_round <- function(x, n=3, seed)
{
  if (!missing(seed)) set.seed(seed)

  rr <- function(x, n){
    if (is.na(x)) return(0)
    if ((x%%n)==0) return(x)
    res <- abs(x)
    lo <- (res%/%n) * n
    if ((runif(1) * n) <= res%%n) res <- lo + n
    else res <- lo
    return(ifelse(x<0, (-1)*res, res))
  }

  isint <- function(x){
    x <- x[!is.na(x)]
    sum(as.integer(x)==x)==length(x)
  }

  if (class(x) %in% c("numeric", "integer")){
    if(isint(x)) return(sapply(x, rr, n))
    else return(x)
  }

  for (i in 1:ncol(x))
  {
    if (class(x[,i]) %in% c("numeric", "integer") & isint(x[,i])) x[,i] <- sapply(x[,i], rr, n)
  }
  x
}
